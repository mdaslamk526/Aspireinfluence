import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const aspireInfluenceLeads = pgTable("aspire_influence_leads", {
  id: serial("id").primaryKey(),
  leadType: text("lead_type").notNull(),
  audienceSegment: text("audience_segment"),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email").notNull(),
  platformDetails: text("platform_details"),
  socialProfiles: text("social_profiles"),
  passions: text("passions"),
  message: text("message"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type AspireInfluenceLead = typeof aspireInfluenceLeads.$inferSelect;
export type NewAspireInfluenceLead = typeof aspireInfluenceLeads.$inferInsert;
