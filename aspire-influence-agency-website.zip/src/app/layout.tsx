import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aspire Influence | Brands × Creators",
  description:
    "Aspire Influence is a social media marketing agency connecting brands with YouTube, Instagram, Hindi, English, tech, and vlog creators for promotional content.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-950 antialiased">{children}</body>
    </html>
  );
}
