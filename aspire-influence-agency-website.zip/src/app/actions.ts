"use server";

import { redirect } from "next/navigation";
import { db } from "@/db";
import { aspireInfluenceLeads } from "@/db/schema";

function textValue(formData: FormData, key: string) {
  const value = formData.get(key);
  return typeof value === "string" ? value.trim() : "";
}

function optionalText(value: string) {
  return value.length > 0 ? value : null;
}

function redirectTarget(formData: FormData, fallbackPath: string, fallbackAnchor: string, type: string) {
  const redirectPath = textValue(formData, "redirectPath") || fallbackPath;
  const successAnchor = textValue(formData, "successAnchor") || fallbackAnchor;
  return `${redirectPath}?submitted=${type}#${successAnchor}`;
}

export async function submitCreatorLead(formData: FormData) {
  const name = textValue(formData, "name");
  const phone = textValue(formData, "phone");
  const email = textValue(formData, "email");
  const platformDetails = textValue(formData, "platformDetails");

  if (!name || !phone || !email || !platformDetails) {
    throw new Error("Creator name, phone, email, and platform details are required.");
  }

  await db.insert(aspireInfluenceLeads).values({
    leadType: "creator",
    audienceSegment: optionalText(textValue(formData, "audienceSegment")),
    name,
    phone,
    email,
    platformDetails,
    socialProfiles: optionalText(textValue(formData, "socialProfiles")),
    passions: optionalText(textValue(formData, "passions")),
    message: optionalText(textValue(formData, "message")),
  });

  redirect(redirectTarget(formData, "/", "creator-intake", "creator"));
}

export async function submitBrandLead(formData: FormData) {
  const name = textValue(formData, "name");
  const email = textValue(formData, "email");
  const message = textValue(formData, "message");

  if (!name || !email || !message) {
    throw new Error("Brand name, email, and message are required.");
  }

  await db.insert(aspireInfluenceLeads).values({
    leadType: "brand",
    audienceSegment: optionalText(textValue(formData, "audienceSegment")),
    name,
    phone: optionalText(textValue(formData, "phone")),
    email,
    platformDetails: optionalText(textValue(formData, "platformDetails")),
    socialProfiles: null,
    passions: null,
    message,
  });

  redirect(redirectTarget(formData, "/contact", "brand-contact", "brand"));
}
