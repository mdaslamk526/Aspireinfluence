import Link from "next/link";
import { BrandLeadForm, SuccessNotice } from "@/components/lead-forms";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function getSubmitted(params: Record<string, string | string[] | undefined>) {
  return typeof params.submitted === "string" ? params.submitted : undefined;
}

export const metadata = {
  title: "Contact Aspire Influence",
  description: "Contact M.D. Aslam at Aspire Influence in Jamshedpur for creator marketing campaigns.",
};

export default async function ContactPage({ searchParams }: { searchParams: SearchParams }) {
  const submitted = getSubmitted(await searchParams);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="border-b border-slate-200 bg-white/90 backdrop-blur">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Link href="/" className="flex items-center gap-3 font-black">
            <span className="grid size-10 place-items-center rounded-2xl bg-orange-500 text-white">AI</span>
            Aspire Influence
          </Link>
          <div className="flex items-center gap-4 text-sm font-bold text-slate-700">
            <Link href="/creators/youtube" className="hover:text-orange-600">YouTube</Link>
            <Link href="/creators/instagram" className="hover:text-orange-600">Instagram</Link>
            <Link href="/#creator-intake" className="rounded-full bg-slate-950 px-4 py-2 text-white hover:bg-orange-600">Join as creator</Link>
          </div>
        </nav>
      </header>

      <section className="bg-slate-950 px-5 py-16 text-white lg:px-8">
        <div className="mx-auto max-w-7xl">
          <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-300">Contact page</p>
          <h1 className="mt-4 max-w-4xl text-5xl font-black leading-tight tracking-tight md:text-7xl">Talk to Aspire Influence about your next creator campaign.</h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
            Brands can submit campaign details here. Aspire Influence will keep a record, reach out, and connect you with suitable creators for promotional content.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-8 px-5 py-16 lg:grid-cols-[0.85fr_1.15fr] lg:px-8">
        <aside className="space-y-5">
          <div className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-xl shadow-slate-200/70">
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Owner details</p>
            <h2 className="mt-4 text-3xl font-black">M.D. Aslam</h2>
            <dl className="mt-6 space-y-4 text-slate-700">
              <div>
                <dt className="text-sm font-black uppercase tracking-[0.18em] text-slate-400">City</dt>
                <dd className="mt-1 text-lg font-semibold">Jamshedpur</dd>
              </div>
              <div>
                <dt className="text-sm font-black uppercase tracking-[0.18em] text-slate-400">Phone</dt>
                <dd className="mt-1 text-lg font-semibold"><a href="tel:8709031423" className="hover:text-orange-600">8709031423</a></dd>
              </div>
              <div>
                <dt className="text-sm font-black uppercase tracking-[0.18em] text-slate-400">Email</dt>
                <dd className="mt-1 text-lg font-semibold"><a href="mailto:aspireinfluence@gmail.com" className="hover:text-orange-600">aspireinfluence@gmail.com</a></dd>
              </div>
            </dl>
          </div>
          <div className="rounded-[2rem] bg-orange-50 p-8 text-slate-800 ring-1 ring-orange-100">
            <h3 className="text-2xl font-black text-slate-950">What to include</h3>
            <ul className="mt-5 space-y-3 text-sm leading-6">
              <li>• Product or service to promote</li>
              <li>• Target city, language, and audience</li>
              <li>• Preferred platform: YouTube, Instagram, or both</li>
              <li>• Expected timeline and deliverables</li>
            </ul>
          </div>
        </aside>

        <div id="brand-contact">
          <SuccessNotice submitted={submitted === "brand" ? submitted : undefined} />
          <BrandLeadForm
            redirectPath="/contact"
            successAnchor="brand-contact"
            idPrefix="contact-brand"
            title="Send your brand enquiry"
            note="Enter your name, email, and campaign message. The submission is stored so Aspire Influence can follow up and connect you with creators."
          />
        </div>
      </section>
    </main>
  );
}
