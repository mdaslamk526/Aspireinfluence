import Link from "next/link";
import { CreatorLeadForm, SuccessNotice } from "@/components/lead-forms";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const youtubeCreators = [
  {
    name: "Tech Explainer Channel",
    niche: "Mobiles, apps, AI tools",
    audience: "Hindi + English tech buyers",
    videos: ["Smartphone review", "AI tool walkthrough", "App launch tutorial"],
    contact: "aspireinfluence@gmail.com",
    phone: "8709031423",
  },
  {
    name: "City Vlog Studio",
    niche: "Food, travel, local lifestyle",
    audience: "Jamshedpur and eastern India viewers",
    videos: ["Restaurant visit vlog", "Weekend travel story", "Festival market video"],
    contact: "aspireinfluence@gmail.com",
    phone: "8709031423",
  },
  {
    name: "Education Shorts Creator",
    niche: "Career, study tips, productivity",
    audience: "Students and first-job professionals",
    videos: ["Study hacks shorts", "Career advice video", "Productivity sponsor integration"],
    contact: "aspireinfluence@gmail.com",
    phone: "8709031423",
  },
];

function getSubmitted(params: Record<string, string | string[] | undefined>) {
  return typeof params.submitted === "string" ? params.submitted : undefined;
}

export const metadata = {
  title: "YouTube Creators | Aspire Influence",
  description: "YouTube creator section for Aspire Influence with video examples, contact details, and creator intake form.",
};

export default async function YouTubeCreatorsPage({ searchParams }: { searchParams: SearchParams }) {
  const submitted = getSubmitted(await searchParams);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="border-b border-slate-200 bg-white/90 backdrop-blur">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Link href="/" className="flex items-center gap-3 font-black">
            <span className="grid size-10 place-items-center rounded-2xl bg-red-600 text-white">YT</span>
            Aspire Influence
          </Link>
          <div className="flex items-center gap-4 text-sm font-bold text-slate-700">
            <Link href="/creators/instagram" className="hover:text-orange-600">Instagram</Link>
            <Link href="/contact" className="hover:text-orange-600">Brands</Link>
            <a href="#youtube-form" className="rounded-full bg-slate-950 px-4 py-2 text-white hover:bg-red-600">Join YouTube list</a>
          </div>
        </nav>
      </header>

      <section className="bg-gradient-to-br from-slate-950 via-red-950 to-slate-900 px-5 py-16 text-white lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-red-200">Dedicated creator page</p>
            <h1 className="mt-4 text-5xl font-black leading-tight tracking-tight md:text-7xl">YouTube creators for reviews, shorts, vlogs, and explainers.</h1>
            <p className="mt-6 text-lg leading-8 text-slate-200">
              Aspire Influence helps brands find YouTube creators for promotional videos, long-form reviews, shorts, tutorials, and city-based integrations.
            </p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-6 shadow-2xl shadow-black/30 backdrop-blur">
            <h2 className="text-2xl font-black">Featured YouTube formats</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {[
                "Product review videos",
                "Shorts and reels repurposing",
                "Tutorial integrations",
                "Vlog brand placements",
              ].map((format) => (
                <div key={format} className="rounded-2xl bg-white/10 p-4 text-sm font-bold text-slate-100">{format}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-sm font-bold uppercase tracking-[0.24em] text-red-600">Creator video examples</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Videos and contact details.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">
            Use these slots to showcase creator videos, niches, audience fit, and contact routing. Brands can request introductions through Aspire Influence.
          </p>
        </div>
        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          {youtubeCreators.map((creator, index) => (
            <article key={creator.name} className="overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-xl shadow-slate-200/70">
              <div className="aspect-video bg-slate-950 p-5 text-white">
                <div className="flex h-full flex-col justify-between rounded-3xl border border-white/10 bg-gradient-to-br from-red-600/40 to-slate-900 p-5">
                  <span className="grid size-12 place-items-center rounded-full bg-red-600 text-lg font-black">▶</span>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.2em] text-red-100">Video slot {index + 1}</p>
                    <h3 className="mt-2 text-xl font-black">{creator.videos[0]}</h3>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-black">{creator.name}</h3>
                <p className="mt-2 text-sm font-bold text-red-700">{creator.niche}</p>
                <p className="mt-3 leading-7 text-slate-600">Audience: {creator.audience}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {creator.videos.map((video) => (
                    <span key={video} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-700">{video}</span>
                  ))}
                </div>
                <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm leading-6 text-slate-700">
                  <p><strong>Contact email:</strong> {creator.contact}</p>
                  <p><strong>Contact phone:</strong> {creator.phone}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="youtube-form" className="bg-white px-5 py-16 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-red-600">YouTube intake form</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Submit your YouTube creator details.</h2>
            <p className="mt-5 text-lg leading-8 text-slate-600">
              Share your channel URL, niche, subscriber count, average views, language, city, phone, and email. Your details are saved for brand shortlisting.
            </p>
          </div>
          <div>
            <SuccessNotice submitted={submitted === "creator" ? submitted : undefined} />
            <CreatorLeadForm
              segment="YouTube creator"
              redirectPath="/creators/youtube"
              successAnchor="youtube-form"
              idPrefix="youtube-creator"
              title="Join the YouTube creator list"
              note="Brands can request YouTube reviewers, vloggers, educators, and shorts creators through Aspire Influence."
            />
          </div>
        </div>
      </section>
    </main>
  );
}
