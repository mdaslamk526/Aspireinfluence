import Link from "next/link";
import { CreatorLeadForm, SuccessNotice } from "@/components/lead-forms";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const instagramCreators = [
  {
    name: "Lifestyle Reel Creator",
    following: "42K followers",
    niche: "Fashion, skincare, city lifestyle",
    topPosts: ["GRWM brand reel", "Skincare carousel", "Festive outfit post"],
    contact: "aspireinfluence@gmail.com",
    phone: "8709031423",
  },
  {
    name: "Food & Cafe Explorer",
    following: "28K followers",
    niche: "Restaurants, cafes, local offers",
    topPosts: ["Cafe launch reel", "Street food story", "Offer announcement post"],
    contact: "aspireinfluence@gmail.com",
    phone: "8709031423",
  },
  {
    name: "Tech Reel Specialist",
    following: "65K followers",
    niche: "Gadgets, apps, AI tools",
    topPosts: ["Phone camera test", "Useful app reel", "AI tool carousel"],
    contact: "aspireinfluence@gmail.com",
    phone: "8709031423",
  },
];

const tiers = [
  ["Nano", "1K–10K", "High trust, local reach, budget-friendly testing"],
  ["Micro", "10K–100K", "Strong niche authority and consistent engagement"],
  ["Mid-tier", "100K+", "Wider reach for launches and larger campaigns"],
];

function getSubmitted(params: Record<string, string | string[] | undefined>) {
  return typeof params.submitted === "string" ? params.submitted : undefined;
}

export const metadata = {
  title: "Instagram Creators | Aspire Influence",
  description: "Instagram creator section for Aspire Influence with following, top posts, contact details, and creator intake form.",
};

export default async function InstagramCreatorsPage({ searchParams }: { searchParams: SearchParams }) {
  const submitted = getSubmitted(await searchParams);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="border-b border-slate-200 bg-white/90 backdrop-blur">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <Link href="/" className="flex items-center gap-3 font-black">
            <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-br from-fuchsia-600 to-orange-500 text-white">IG</span>
            Aspire Influence
          </Link>
          <div className="flex items-center gap-4 text-sm font-bold text-slate-700">
            <Link href="/creators/youtube" className="hover:text-orange-600">YouTube</Link>
            <Link href="/contact" className="hover:text-orange-600">Brands</Link>
            <a href="#instagram-form" className="rounded-full bg-slate-950 px-4 py-2 text-white hover:bg-orange-600">Join Instagram list</a>
          </div>
        </nav>
      </header>

      <section className="bg-gradient-to-br from-fuchsia-900 via-orange-600 to-amber-400 px-5 py-16 text-white lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-white/80">Dedicated creator section</p>
            <h1 className="mt-4 text-5xl font-black leading-tight tracking-tight md:text-7xl">Instagram creators for reels, posts, stories, and local influence.</h1>
            <p className="mt-6 text-lg leading-8 text-white/90">
              Aspire Influence lists Instagram creators by following, niche, top posts, audience language, and campaign fit so brands can move faster.
            </p>
          </div>
          <div className="grid gap-4">
            {tiers.map(([tier, followers, copy]) => (
              <div key={tier} className="rounded-3xl border border-white/20 bg-white/15 p-5 shadow-xl shadow-orange-950/20 backdrop-blur">
                <div className="flex items-center justify-between gap-4">
                  <h2 className="text-2xl font-black">{tier}</h2>
                  <span className="rounded-full bg-white px-4 py-2 text-sm font-black text-slate-950">{followers}</span>
                </div>
                <p className="mt-3 leading-7 text-white/90">{copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Instagram following and top posts</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Creator cards for brand shortlisting.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">
            Each Instagram profile can show following, niche, top performing post ideas, and contact routing through Aspire Influence.
          </p>
        </div>
        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          {instagramCreators.map((creator) => (
            <article key={creator.name} className="overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-xl shadow-slate-200/70">
              <div className="bg-gradient-to-br from-fuchsia-600 via-orange-500 to-amber-300 p-1">
                <div className="rounded-[1.8rem] bg-white/15 p-5 text-white">
                  <p className="text-sm font-bold uppercase tracking-[0.22em] text-white/80">Top post preview</p>
                  <h3 className="mt-16 text-3xl font-black leading-tight">{creator.topPosts[0]}</h3>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <h3 className="text-2xl font-black">{creator.name}</h3>
                  <span className="rounded-full bg-orange-100 px-3 py-1 text-xs font-black text-orange-700">{creator.following}</span>
                </div>
                <p className="mt-3 font-bold text-slate-700">{creator.niche}</p>
                <div className="mt-5 space-y-2">
                  {creator.topPosts.map((post) => (
                    <p key={post} className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">{post}</p>
                  ))}
                </div>
                <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm leading-6 text-slate-700">
                  <p><strong>Contact email:</strong> {creator.contact}</p>
                  <p><strong>Contact phone:</strong> {creator.phone}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="instagram-form" className="bg-white px-5 py-16 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Instagram intake form</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Submit your Instagram creator details.</h2>
            <p className="mt-5 text-lg leading-8 text-slate-600">
              Share your handle, followers, niche, top posts, average reel views, city, language, phone, and email. Your contact is saved for future brand campaigns.
            </p>
          </div>
          <div>
            <SuccessNotice submitted={submitted === "creator" ? submitted : undefined} />
            <CreatorLeadForm
              segment="Instagram creator"
              redirectPath="/creators/instagram"
              successAnchor="instagram-form"
              idPrefix="instagram-creator"
              title="Join the Instagram creator list"
              note="Brands can request reel creators, local influencers, lifestyle pages, tech reviewers, and niche community profiles."
            />
          </div>
        </div>
      </section>
    </main>
  );
}
