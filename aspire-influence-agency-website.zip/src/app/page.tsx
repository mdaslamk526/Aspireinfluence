import Link from "next/link";
import { BrandLeadForm, CreatorLeadForm, SuccessNotice } from "@/components/lead-forms";

const googleFormUrl = process.env.NEXT_PUBLIC_GOOGLE_FORM_URL ?? "https://docs.google.com/forms/";

const states = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Jammu & Kashmir",
];

const creatorSegments = [
  {
    title: "Hindi audience creators",
    segment: "Hindi audience",
    description: "Regional storytelling, product explainers, comedy skits, lifestyle reels, and mass-market campaigns for Bharat audiences.",
    examples: ["Shorts in Hindi", "Family buying decisions", "Tier 2 and Tier 3 city reach"],
    id: "hindi",
  },
  {
    title: "English audience creators",
    segment: "English audience",
    description: "Premium positioning for urban lifestyle, education, SaaS, personal finance, travel, fashion, and D2C brands.",
    examples: ["Polished review videos", "High-trust carousels", "Professional audience fit"],
    id: "english",
  },
  {
    title: "Tech creators",
    segment: "Tech creators",
    description: "Gadget reviews, software tutorials, AI tools, mobile apps, and founder-led explainers for performance-focused launches.",
    examples: ["Unboxing + review", "App walkthrough", "How-to tutorials"],
    id: "tech",
  },
  {
    title: "Vloggers",
    segment: "Vloggers",
    description: "Authentic daily-life integrations across food, local travel, campus culture, fitness, festivals, and city experiences.",
    examples: ["Day-in-life placement", "Restaurant visits", "Travel stories"],
    id: "vloggers",
  },
];

const testimonials = [
  {
    quote: "Aspire Influence helped us find creators who actually understood our product and audience. The campaign felt personal, not forced.",
    name: "Aarav Mehta",
    role: "D2C brand founder",
  },
  {
    quote: "The team explained the brand brief clearly and made the collaboration smooth. I could focus on content while they handled coordination.",
    name: "Priya Sharma",
    role: "Lifestyle creator",
  },
  {
    quote: "For a local launch, we needed regional voices. Aspire Influence shortlisted creators fast and kept communication professional.",
    name: "Nisha Verma",
    role: "Restaurant marketing lead",
  },
];

const faqs = [
  {
    question: "How does Aspire Influence connect brands and creators?",
    answer: "Brands submit campaign goals, target audience, city, niche, budget range, and timeline. Creators submit their platform details. Aspire Influence shortlists the best fit and coordinates the collaboration.",
  },
  {
    question: "Are there purchase packages?",
    answer: "No. Aspire Influence focuses on collecting quality contact information and matching brands with creators. Commission-based profit is earned only after successful brand-creator deals happen.",
  },
  {
    question: "How are payments handled?",
    answer: "Payment terms are discussed campaign by campaign. Creator pricing, deliverables, timelines, and commission are clarified before content goes live.",
  },
  {
    question: "How long does shortlisting take?",
    answer: "Simple campaigns can be shortlisted quickly after receiving details. Larger campaigns may need extra time for niche, language, region, and audience matching.",
  },
];

const blogPosts = [
  {
    title: "How regional creators build trust faster than generic ads",
    tag: "Trend",
    summary: "Indian audiences respond strongly to familiar language, city culture, and authentic product usage.",
  },
  {
    title: "Creator brief checklist for better sponsored content",
    tag: "Tips",
    summary: "Define the hook, product benefits, must-say points, usage scene, timeline, and approval process before shooting.",
  },
  {
    title: "From local launch to repeat creator campaigns",
    tag: "Success story",
    summary: "A practical approach to testing micro creators first, then scaling with stronger audience data.",
  },
];

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

function getSubmitted(params: Record<string, string | string[] | undefined>) {
  return typeof params.submitted === "string" ? params.submitted : undefined;
}

export default async function HomePage({ searchParams }: { searchParams: SearchParams }) {
  const submitted = getSubmitted(await searchParams);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="sticky top-0 z-50 border-b border-white/20 bg-slate-950/85 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 text-white lg:px-8">
          <Link href="/" className="flex items-center gap-3 font-black tracking-tight">
            <span className="grid size-10 place-items-center rounded-2xl bg-orange-500 text-lg shadow-lg shadow-orange-950/30">AI</span>
            <span>
              <span className="block text-lg leading-none">Aspire Influence</span>
              <span className="text-xs font-medium text-slate-300">Brands × Creators</span>
            </span>
          </Link>
          <div className="hidden items-center gap-6 text-sm font-semibold text-slate-200 md:flex">
            <Link href="/creators/youtube" className="hover:text-orange-300">YouTube</Link>
            <Link href="/creators/instagram" className="hover:text-orange-300">Instagram</Link>
            <a href="#segments" className="hover:text-orange-300">Audiences</a>
            <a href="#faq" className="hover:text-orange-300">FAQ</a>
            <Link href="/contact" className="rounded-full bg-white px-5 py-2 text-slate-950 hover:bg-orange-100">Contact</Link>
          </div>
        </nav>
      </header>

      <section
        className="relative isolate overflow-hidden bg-cover bg-center px-5 py-24 text-white lg:px-8 lg:py-32"
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(2,6,23,0.92), rgba(15,23,42,0.78), rgba(194,65,12,0.42)), url('/images/india-states-hero.jpg')",
        }}
      >
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_20%,rgba(251,146,60,0.30),transparent_28%),radial-gradient(circle_at_80%_30%,rgba(16,185,129,0.18),transparent_30%)]" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="inline-flex rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold text-orange-100 backdrop-blur">
              Premium social media marketing agency from Jamshedpur
            </p>
            <h1 className="mt-7 max-w-4xl text-5xl font-black leading-[0.96] tracking-tight md:text-7xl">
              Connecting brands with creators for promotional content that feels authentic.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-100">
              Aspire Influence helps brands discover YouTube, Instagram, Hindi, English, tech, and vlogging creators across India. We collect verified contact details, shortlist the right talent, coordinate campaigns, and earn commission when real deals happen.
            </p>
            <div className="mt-9 flex flex-col gap-4 sm:flex-row">
              <Link href="/contact#brand-contact" className="rounded-2xl bg-orange-500 px-7 py-4 text-center text-sm font-black uppercase tracking-[0.16em] text-white shadow-2xl shadow-orange-950/40 transition hover:-translate-y-1 hover:bg-orange-400">
                Brands contact us
              </Link>
              <a href="#creator-intake" className="rounded-2xl border border-white/25 bg-white/10 px-7 py-4 text-center text-sm font-black uppercase tracking-[0.16em] text-white backdrop-blur transition hover:-translate-y-1 hover:bg-white hover:text-slate-950">
                Creators join list
              </a>
            </div>
          </div>
          <div className="rounded-[2rem] border border-white/15 bg-white/10 p-5 shadow-2xl shadow-slate-950/50 backdrop-blur-xl">
            <div className="rounded-[1.5rem] bg-slate-950/75 p-6">
              <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-300">29-state creator identity map</p>
              <h2 className="mt-3 text-3xl font-black">Pan-India cultural reach</h2>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                Campaign planning inspired by language, culture, festivals, cities, and creator communities across Indian states.
              </p>
              <div className="mt-5 flex max-h-72 flex-wrap gap-2 overflow-hidden">
                {states.map((state) => (
                  <span key={state} className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-semibold text-slate-100">
                    {state}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-14 lg:grid-cols-3 lg:px-8">
        {[
          ["1", "Collect", "Creators and brands submit clean contact details, passions, profiles, and campaign needs."],
          ["2", "Shortlist", "Aspire Influence matches audience, platform, language, niche, location, and content style."],
          ["3", "Connect", "Once both sides agree, the deal moves forward and commission is earned after success."],
        ].map(([step, title, copy]) => (
          <div key={step} className="rounded-3xl border border-slate-200 bg-white p-7 shadow-xl shadow-slate-200/60">
            <span className="grid size-12 place-items-center rounded-2xl bg-orange-100 text-lg font-black text-orange-700">{step}</span>
            <h2 className="mt-5 text-2xl font-black">{title}</h2>
            <p className="mt-3 leading-7 text-slate-600">{copy}</p>
          </div>
        ))}
      </section>

      <section id="packages" className="bg-slate-950 px-5 py-16 text-white lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-300">No purchase packages</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Built for contact collection and commission-based deals.</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              "Creators submit platform details and passions.",
              "Brands submit campaign goals and messages.",
              "Aspire Influence links the right people.",
              "Profit happens through commission after deals close.",
            ].map((item) => (
              <div key={item} className="rounded-3xl border border-white/10 bg-white/10 p-5 text-sm font-semibold leading-6 text-slate-100">
                {item}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="creator-intake" className="mx-auto grid max-w-7xl gap-8 px-5 py-16 lg:grid-cols-[0.95fr_1.05fr] lg:px-8">
        <div>
          <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Creator intake</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Join the Aspire Influence creator contact list.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">
            Submit your name, phone, email, platform details, passions, and social media profiles. The form helps us shortlist creators for brands looking for relevant promotional content.
          </p>
          <div className="mt-8 rounded-3xl border border-orange-200 bg-orange-50 p-6">
            <h3 className="text-xl font-black text-slate-950">Google Form option</h3>
            <p className="mt-2 text-sm leading-6 text-slate-700">
              Prefer a Google Form? Use this button to submit creator contact info, passions, and social media profiles.
            </p>
            <a href={googleFormUrl} target="_blank" rel="noreferrer" className="mt-5 inline-flex rounded-2xl bg-orange-600 px-6 py-3 text-sm font-bold text-white transition hover:bg-slate-950">
              Open creator Google Form
            </a>
          </div>
        </div>
        <div id="creator-form">
          <SuccessNotice submitted={submitted === "creator" ? submitted : undefined} />
          <CreatorLeadForm segment="General creator" redirectPath="/" successAnchor="creator-intake" idPrefix="home-creator" title="Submit your creator profile" />
        </div>
      </section>

      <section className="bg-white px-5 py-16 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Platform sections</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Separate creator pages for YouTube and Instagram.</h2>
            </div>
            <p className="text-lg leading-8 text-slate-600">
              Explore creator formats, example video slots, Instagram following tiers, top post ideas, and dedicated forms for platform-specific shortlisting.
            </p>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            <Link href="/creators/youtube" className="group rounded-[2rem] border border-slate-200 bg-slate-950 p-8 text-white shadow-2xl shadow-slate-200 transition hover:-translate-y-1">
              <p className="text-sm font-bold uppercase tracking-[0.24em] text-red-300">YouTube creators</p>
              <h3 className="mt-4 text-3xl font-black">Videos, long-form reviews, shorts and creator contact details.</h3>
              <span className="mt-8 inline-flex font-bold text-orange-300 group-hover:text-white">View YouTube page →</span>
            </Link>
            <Link href="/creators/instagram" className="group rounded-[2rem] border border-slate-200 bg-gradient-to-br from-fuchsia-700 via-orange-500 to-amber-400 p-8 text-white shadow-2xl shadow-orange-100 transition hover:-translate-y-1">
              <p className="text-sm font-bold uppercase tracking-[0.24em] text-white/80">Instagram creators</p>
              <h3 className="mt-4 text-3xl font-black">Following data, reel concepts, top posts and influencer profiles.</h3>
              <span className="mt-8 inline-flex font-bold text-white">View Instagram page →</span>
            </Link>
          </div>
        </div>
      </section>

      <section id="segments" className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Audience and niche sections</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Hindi, English, tech, and vlog creator lists.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">
            Every section includes creator examples and a contact form that saves name, phone, email, platform details, profiles, and passions.
          </p>
        </div>
        <div className="mt-10 grid gap-8 lg:grid-cols-2">
          {creatorSegments.map((creator) => (
            <article key={creator.id} id={creator.id} className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-xl shadow-slate-200/60">
              <h3 className="text-2xl font-black text-slate-950">{creator.title}</h3>
              <p className="mt-3 leading-7 text-slate-600">{creator.description}</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                {creator.examples.map((example) => (
                  <span key={example} className="rounded-2xl bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">
                    {example}
                  </span>
                ))}
              </div>
              <div className="mt-6">
                <CreatorLeadForm
                  segment={creator.segment}
                  redirectPath="/"
                  successAnchor={creator.id}
                  idPrefix={`segment-${creator.id}`}
                  title={`Join as ${creator.title.toLowerCase()}`}
                  compact
                />
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-slate-100 px-5 py-16 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Brand enquiry</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Need creators for your next campaign?</h2>
            <p className="mt-5 text-lg leading-8 text-slate-600">
              Brands can enter their name, email, and message so Aspire Influence can keep a record and reach out with matching creators.
            </p>
          </div>
          <div id="brand-contact">
            <SuccessNotice submitted={submitted === "brand" ? submitted : undefined} />
            <BrandLeadForm redirectPath="/" successAnchor="brand-contact" idPrefix="home-brand" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Trust signals</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Reviews from brands and creators.</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {testimonials.map((testimonial) => (
              <blockquote key={testimonial.name} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xl shadow-slate-200/60">
                <p className="leading-7 text-slate-700">“{testimonial.quote}”</p>
                <footer className="mt-5">
                  <p className="font-black text-slate-950">{testimonial.name}</p>
                  <p className="text-sm text-orange-700">{testimonial.role}</p>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="bg-white px-5 py-16 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">FAQ</p>
          <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Common questions.</h2>
          <div className="mt-10 divide-y divide-slate-200 rounded-[2rem] border border-slate-200 bg-slate-50">
            {faqs.map((faq) => (
              <details key={faq.question} className="group p-6" open={faq.question.includes("connect")}>
                <summary className="cursor-pointer list-none text-lg font-black text-slate-950">
                  {faq.question}
                  <span className="float-right text-orange-600 group-open:rotate-45">+</span>
                </summary>
                <p className="mt-4 leading-7 text-slate-600">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section id="blog" className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-orange-600">Blog</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Industry tips, trends, and stories.</h2>
          </div>
          <Link href="/contact" className="rounded-2xl bg-slate-950 px-6 py-3 text-center text-sm font-bold text-white hover:bg-orange-600">Discuss a campaign</Link>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {blogPosts.map((post) => (
            <article key={post.title} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xl shadow-slate-200/60">
              <span className="rounded-full bg-orange-100 px-3 py-1 text-xs font-black uppercase tracking-[0.18em] text-orange-700">{post.tag}</span>
              <h3 className="mt-5 text-xl font-black leading-tight text-slate-950">{post.title}</h3>
              <p className="mt-3 leading-7 text-slate-600">{post.summary}</p>
            </article>
          ))}
        </div>
      </section>

      <footer className="bg-slate-950 px-5 py-12 text-white lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-black">Aspire Influence</h2>
            <p className="mt-4 max-w-xl leading-7 text-slate-300">
              A creator-brand connector focused on promotional content, verified contact lists, professional shortlisting, and commission-based collaboration.
            </p>
          </div>
          <div>
            <h3 className="font-black text-orange-300">Owner</h3>
            <p className="mt-3 text-slate-300">M.D. Aslam</p>
            <p className="text-slate-300">Jamshedpur</p>
          </div>
          <div>
            <h3 className="font-black text-orange-300">Contact</h3>
            <p className="mt-3 text-slate-300">8709031423</p>
            <p className="text-slate-300">aspireinfluence@gmail.com</p>
            <Link href="/contact" className="mt-4 inline-flex font-bold text-white hover:text-orange-300">Open contact page →</Link>
          </div>
        </div>
      </footer>
    </main>
  );
}
