import { submitBrandLead, submitCreatorLead } from "@/app/actions";

type CreatorLeadFormProps = {
  segment: string;
  redirectPath: string;
  successAnchor: string;
  idPrefix: string;
  title?: string;
  note?: string;
  compact?: boolean;
};

type BrandLeadFormProps = {
  redirectPath: string;
  successAnchor: string;
  idPrefix: string;
  title?: string;
  note?: string;
};

const inputClass =
  "w-full rounded-2xl border border-slate-200 bg-white/95 px-4 py-3 text-sm text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-orange-400 focus:ring-4 focus:ring-orange-100";
const labelClass = "text-sm font-semibold text-slate-800";

export function SuccessNotice({ submitted }: { submitted?: string }) {
  if (!submitted) {
    return null;
  }

  const message =
    submitted === "brand"
      ? "Thanks! Your brand enquiry has been saved. Aspire Influence will contact you soon."
      : "Thanks! Your creator details have been saved for brand shortlisting.";

  return (
    <div className="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm font-medium text-emerald-800">
      {message}
    </div>
  );
}

export function CreatorLeadForm({
  segment,
  redirectPath,
  successAnchor,
  idPrefix,
  title = "Creator contact form",
  note = "Share your details so Aspire Influence can shortlist you for relevant brand campaigns.",
  compact = false,
}: CreatorLeadFormProps) {
  return (
    <form action={submitCreatorLead} className="space-y-4 rounded-3xl border border-white/70 bg-white/90 p-5 shadow-xl shadow-slate-200/60 backdrop-blur">
      <input type="hidden" name="audienceSegment" value={segment} />
      <input type="hidden" name="redirectPath" value={redirectPath} />
      <input type="hidden" name="successAnchor" value={successAnchor} />
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.24em] text-orange-600">{segment}</p>
        <h3 className="mt-1 text-xl font-bold text-slate-950">{title}</h3>
        <p className="mt-2 text-sm leading-6 text-slate-600">{note}</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-2" htmlFor={`${idPrefix}-name`}>
          <span className={labelClass}>Creator name</span>
          <input id={`${idPrefix}-name`} name="name" required className={inputClass} placeholder="Your full name" />
        </label>
        <label className="space-y-2" htmlFor={`${idPrefix}-phone`}>
          <span className={labelClass}>Phone number</span>
          <input id={`${idPrefix}-phone`} name="phone" required className={inputClass} placeholder="WhatsApp / phone" inputMode="tel" />
        </label>
        <label className="space-y-2" htmlFor={`${idPrefix}-email`}>
          <span className={labelClass}>Email</span>
          <input id={`${idPrefix}-email`} name="email" type="email" required className={inputClass} placeholder="you@example.com" />
        </label>
        <label className="space-y-2" htmlFor={`${idPrefix}-profiles`}>
          <span className={labelClass}>Social media profiles</span>
          <input id={`${idPrefix}-profiles`} name="socialProfiles" className={inputClass} placeholder="YouTube, Instagram, LinkedIn links" />
        </label>
      </div>
      <label className="block space-y-2" htmlFor={`${idPrefix}-platform`}>
        <span className={labelClass}>Platform details</span>
        <textarea
          id={`${idPrefix}-platform`}
          name="platformDetails"
          required
          rows={compact ? 3 : 4}
          className={inputClass}
          placeholder="Platform, niche, subscribers/followers, average views, audience city/language"
        />
      </label>
      {!compact && (
        <label className="block space-y-2" htmlFor={`${idPrefix}-passions`}>
          <span className={labelClass}>Passions and content themes</span>
          <textarea
            id={`${idPrefix}-passions`}
            name="passions"
            rows={3}
            className={inputClass}
            placeholder="Tech, fashion, food, education, travel, comedy, finance, lifestyle..."
          />
        </label>
      )}
      <button className="w-full rounded-2xl bg-slate-950 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-slate-300 transition hover:-translate-y-0.5 hover:bg-orange-600" type="submit">
        Submit creator details
      </button>
    </form>
  );
}

export function BrandLeadForm({
  redirectPath,
  successAnchor,
  idPrefix,
  title = "Brand contact form",
  note = "Tell us your campaign goal and we will match you with suitable creators.",
}: BrandLeadFormProps) {
  return (
    <form action={submitBrandLead} className="space-y-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl shadow-slate-200/70">
      <input type="hidden" name="redirectPath" value={redirectPath} />
      <input type="hidden" name="successAnchor" value={successAnchor} />
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.24em] text-orange-600">For brands</p>
        <h3 className="mt-1 text-2xl font-bold text-slate-950">{title}</h3>
        <p className="mt-2 text-sm leading-6 text-slate-600">{note}</p>
      </div>
      <label className="block space-y-2" htmlFor={`${idPrefix}-name`}>
        <span className={labelClass}>Brand / contact name</span>
        <input id={`${idPrefix}-name`} name="name" required className={inputClass} placeholder="Your brand or name" />
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-2" htmlFor={`${idPrefix}-email`}>
          <span className={labelClass}>Email</span>
          <input id={`${idPrefix}-email`} name="email" type="email" required className={inputClass} placeholder="brand@example.com" />
        </label>
        <label className="space-y-2" htmlFor={`${idPrefix}-phone`}>
          <span className={labelClass}>Phone number</span>
          <input id={`${idPrefix}-phone`} name="phone" className={inputClass} placeholder="Optional" inputMode="tel" />
        </label>
      </div>
      <label className="block space-y-2" htmlFor={`${idPrefix}-details`}>
        <span className={labelClass}>Campaign details</span>
        <input id={`${idPrefix}-details`} name="platformDetails" className={inputClass} placeholder="Preferred platform, niche, city, budget range" />
      </label>
      <label className="block space-y-2" htmlFor={`${idPrefix}-message`}>
        <span className={labelClass}>Message</span>
        <textarea id={`${idPrefix}-message`} name="message" required rows={5} className={inputClass} placeholder="Tell us what you want to promote and your timeline." />
      </label>
      <button className="w-full rounded-2xl bg-orange-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-orange-200 transition hover:-translate-y-0.5 hover:bg-slate-950" type="submit">
        Send brand enquiry
      </button>
    </form>
  );
}
